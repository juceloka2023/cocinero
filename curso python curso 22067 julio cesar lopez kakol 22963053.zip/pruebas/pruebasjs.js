fc = ((a) => a + 100)

console.log( fc(10) )